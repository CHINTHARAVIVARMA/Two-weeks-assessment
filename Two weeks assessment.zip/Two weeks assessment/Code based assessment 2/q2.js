var num1 = prompt("enter the input:");
var result = '';
switch (num1) {
    case 'A':
        result = "Excellent";
        alert(result);
        break;
    case 'B':
        result = "Good";
        alert(result);
        break;
    case 'C':
        result = "Fair";
        alert(result);
        break;
    case 'D':
        result = "Poor";
        alert(result);
        break;
    default: {
        alert("Invalid Input");
        break;
    }
}
